/*
    Implementation of the KNN algorithm that sorts individuals. it has methods
    to return the individuals to help test. It also includes methods that
    returns the two keywords files to verify their accuracy.
 */

import java.util.ArrayList;

public class Knn {

    private ArrayList<Individual> individuals; // stores list of Individuals to make teams from
    private Individual[] sortedIndividuals;
    // stores sorted Individuals by distance to target for model
    private String softKeywordsFilename; // stores name of soft skills keywords filename
    private String hardKeywordsFilename; // stores name of hard skills keywords filename

    // Create a knn model
    public Knn(String individualProfiles) {

        // Initialize individuals array
        individuals = new ArrayList<Individual>();

        In individualProfilesStream = new In(individualProfiles);

        // Store keywords
        softKeywordsFilename = individualProfilesStream.readString();
        hardKeywordsFilename = individualProfilesStream.readString();

        while (!individualProfilesStream.isEmpty()) {
            String individualFilename = individualProfilesStream.readString();
            Individual currentIndividual = new Individual(individualFilename, softKeywordsFilename,
                                                          hardKeywordsFilename);
            individuals.add(currentIndividual);
        }

        // Initialize sortedlist length
        sortedIndividuals = new Individual[individuals.size()];

    }

    // Return the individuals in model
    public ArrayList<Individual> getIndividuals() {
        return individuals;
    }

    // Compute Euclidean distance between Individual vectors and assigns distance to model
    public void setDistances(Individual target, ArrayList<Individual> others) {
        for (int i = 0; i < others.size(); i++) {
            others.get(i).setDistance(target);
        }
    }

    // Sort distances using mergesort based on an individual
    public void sortIndividuals() {
        for (int i = 0; i < individuals.size(); i++) {
            sortedIndividuals[i] = individuals.get(i);
        }
        Merge.sort(sortedIndividuals);
    }

    // Return sorted individuals
    public Individual[] getSortedIndividuals() {
        return sortedIndividuals;
    }

    // Take the first k distances from the sorted list and return the most common label
    public double predict(int k) {
        int lowCounter = 0;
        int mediumCounter = 0;
        int highCounter = 0;
        double result = 0.0;

        for (int i = 0; i < k; i++) {
            if (sortedIndividuals[i].label() == -1.0) lowCounter++;
            else if (sortedIndividuals[i].label() == 0.0) mediumCounter++;
            else if (sortedIndividuals[i].label() == 1.0) highCounter++;
        }

        // Return the highest number of classes counted, picking the higher class if there is a tie
        double max = Math.max(highCounter, Math.max(mediumCounter, lowCounter));
        if (max == highCounter) result = 1.0;
        else if (max == mediumCounter) result = 0.0;
        else result = -1.0;

        return result;
    }

    // returns soft keywords file
    public String softKeywordsFilename() {
        return softKeywordsFilename;
    }

    // returns soft keywords file
    public String hardKeywordsFilename() {
        return hardKeywordsFilename;
    }


    public static void main(String[] args) {

        // Test constructor
        Knn model = new Knn("individual-profiles.txt");
        Individual aidan = new Individual("aidan-test.txt", "soft-keywords.txt",
                                          "hard-keywords.txt");

        // Test setDistances, getIndividuals, getSortedIndividuals, and sortIndividuals methods
        model.setDistances(aidan, model.getIndividuals());
        StdOut.println("unsorted distances: ");
        for (int i = 0; i < model.getIndividuals().size(); i++) {
            StdOut.println(model.getIndividuals().get(i).name() + ": " +
                                   model.getIndividuals().get(i).distance());
        }
        StdOut.println();

        model.sortIndividuals();

        StdOut.println("sorted distances: ");
        double[] distances = new double[model.getIndividuals().size()];
        for (int i = 0; i < model.getIndividuals().size(); i++) {
            StdOut.println(model.getSortedIndividuals()[i].name() + ": " +
                                   model.getSortedIndividuals()[i].distance());
            distances[i] = model.getSortedIndividuals()[i].distance();

        }

        boolean isOrdered = true;
        for (int i = 0; i < distances.length - 1; i++) {
            if (distances[i] > distances[i + 1]) {
                isOrdered = false;
            }
        }
        if (isOrdered) StdOut.println("passed");
        StdOut.println();

        // Test predict method
        StdOut.println("Prediction expected value: 1.0");
        StdOut.println("Result: " + model.predict(3)); // Expected value: 1.0
        if (model.predict(3) == 1.0) StdOut.println("passed");
        StdOut.println();

        // Test softKeywordsFilename and hardKeywordsFilename methods

        StdOut.println("softKeywordsFilename expected value: soft-keywords.txt");
        StdOut.println(
                "Result: " + model.softKeywordsFilename()); // Expected value: soft-keywords.txt
        if (model.softKeywordsFilename.equals("soft-keywords.txt")) StdOut.println("passed");
        StdOut.println();

        StdOut.println("hardKeywordsFilename expected value: hard-keywords.txt");
        StdOut.println(
                "Result: " + model.hardKeywordsFilename()); // Expected value: hard-keywords.txt
        if (model.hardKeywordsFilename.equals("hard-keywords.txt")) StdOut.println("passed");
    }
}
