/*
    Generates random number using three different seeds. It is based on the
    Wichman-Hill Random Number Generator that takes three seeds and inserts
    them into an equation resulting in good pseudo-random numbers.
 */

public class RandomNumber {

    private int seed1; // stores the generator's first seed
    private int seed2; // stores the generator's second seed
    private int seed3; // stores the generator's third seed

    // Initializes a random number generator with zero seeds
    public RandomNumber() {
        seed1 = 0;
        seed2 = 0;
        seed3 = 0;
    }

    // Initializes a random number generator with preset seeds
    public RandomNumber(int seed1, int seed2, int seed3) {
        this.seed1 = seed1;
        this.seed2 = seed2;
        this.seed3 = seed3;
    }

    // Use seeds in random number generator to produce a random number
    public double random() {
        int MAX = 30000;
        seed1 = (((int) (Math.random() * MAX)) * 171) % 30269;
        seed2 = (((int) (Math.random() * MAX)) * 172) % 30307;
        seed3 = (((int) (Math.random() * MAX)) * 170) % 30323;
        return ((seed1 / 30269.0) + (seed2 / 30307.0) + (seed3 / 30323.0)) % 1;
    }

    // Return the seeds of the random number generator
    public String toString() {
        return "s1: " + seed1 + ", s2: " + seed2 + ", s3: " + seed3;
    }

    // Test methods in RandomNumber class
    public static void main(String[] args) {

        // Test first randomNumber constructor
        RandomNumber randomNumber = new RandomNumber();

        // Test toString method
        StdOut.println("Expected  string: s1: 0, s2: 0, s3: 0");
        String expectedString = "s1: 0, s2: 0, s3: 0";
        StdOut.println("Result: " + randomNumber); // Expected value: s1:  0, s2: 0, s3: 0
        if (randomNumber.toString().equals(expectedString)) StdOut.println("passed");
        StdOut.println();

        // Test random method
        StdOut.println("Expected random value: 0 < x < 1");
        double random = randomNumber.random();
        StdOut.println("Result: " + random); // Expected value: 0 < x < 1
        if (random < 1 && random > 0) StdOut.println("passed");
        StdOut.println();

        // Test second randomNumber constructor
        RandomNumber randomNumber2 = new RandomNumber(3218, 15430, 23951);
        String expectedResult = "s1: 3218, s2: 15430, s3: 23951";
        StdOut.println("Expected string: " + expectedResult);
        StdOut.println(
                "Result: " + randomNumber2); // Expected value: s1:  3218, s2: 15430, s3: 23951
        if (expectedResult.equals(randomNumber2.toString())) StdOut.println("passed");
        StdOut.println();

        // Verify randomness of randomNumber generator
        double counter = 0.0;
        for (int i = 0; i < 1000; i++) {
            counter += randomNumber.random();
        }

        StdOut.println("Expected average number: ~0.50");
        StdOut.println("Result: " + (counter / 1000));
        if (Math.abs((counter / 1000) - 0.5) < 0.1) StdOut.println("passed");
    }
}
