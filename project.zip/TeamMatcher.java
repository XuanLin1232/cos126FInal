/*
       Creates teams by predicting individuals and adding them to
       the respective level of skill and generating balanced teams randomly.
       It makes sure the teams have the correct distributions and fall under
       a specific tolerance.
 */

import java.util.ArrayList;

public class TeamMatcher {

    private int size; // describes the size of teams to be made from the set
    private Knn model; // model which classifies skill level of new individuals
    private ArrayList<Individual> individuals;
    // contains all Individuals to be sorted ijavanto teams
    private ArrayList<Individual> highSkill; // contains all Individuals ranked high skill
    private ArrayList<Individual> mediumSkill; // contains all Individuals ranked medium skill
    private ArrayList<Individual> lowSkill; // contains all Individuals ranked low skill

    // Create a TeamMatcher object
    public TeamMatcher(String trainingProfiles, String testingProfiles, int size) {

        // Select team size and train model
        this.size = size;
        model = new Knn(trainingProfiles);

        // Initialize individual arrays
        individuals = new ArrayList<Individual>();
        highSkill = new ArrayList<Individual>();
        mediumSkill = new ArrayList<Individual>();
        lowSkill = new ArrayList<Individual>();


        In testingProfilesStream = new In(testingProfiles);

        // Add individuals to matcher
        while (!testingProfilesStream.isEmpty()) {
            String testingProfileFilename = testingProfilesStream.readString();
            Individual currentIndividual = new Individual(testingProfileFilename,
                                                          model.softKeywordsFilename(),
                                                          model.hardKeywordsFilename());
            individuals.add(currentIndividual);
        }


    }

    // Returns unsorted individuals arraylist
    public ArrayList<Individual> getUnsorted() {
        ArrayList<Individual> result = new ArrayList<Individual>();

        for (int i = 0; i < individuals.size(); i++) {
            result.add(individuals.get(i));
        }

        return result;
    }

    // Classify skill levels of input (populate skill arrays)
    public void classify() {
        for (int i = 0; i < individuals.size(); i++) {
            Individual currentIndividual = individuals.get(i);
            model.setDistances(currentIndividual, model.getIndividuals());
            model.sortIndividuals();
            double prediction = model.predict(size);
            if (prediction == 1.0) {
                highSkill.add(currentIndividual);

            }
            else if (prediction == 0.0) {
                mediumSkill.add(currentIndividual);
                StdOut.println("worked");
            }
            else {
                lowSkill.add(currentIndividual);
                StdOut.println("worked");
            }

        }

    }

    // Add high skill individual
    private Individual highSkillIndividual() {
        RandomNumber random = new RandomNumber();
        if (highSkill.isEmpty()) {
            throw new RuntimeException("empty");
        }
        Individual result = highSkill.get((int) (random.random() * highSkill.size()));
        highSkill.remove(result);
        return result;
    }

    // Add medium skill individual
    private Individual mediumSkillIndividual() {
        RandomNumber random = new RandomNumber();
        if (mediumSkill.isEmpty()) throw new RuntimeException("empty");
        Individual result = mediumSkill.get((int) (random.random() * mediumSkill.size()));
        mediumSkill.remove(result);
        return result;
    }

    // Add high skill individual
    private Individual lowSkillIndividual() {
        RandomNumber random = new RandomNumber();
        if (lowSkill.isEmpty()) {
            throw new RuntimeException("empty");
        }
        Individual result = lowSkill.get((int) (random.random() * lowSkill.size()));
        lowSkill.remove(result);
        return result;
    }

    // Add random individual
    private Individual randomIndividual() {
        RandomNumber random = new RandomNumber();
        Individual result;
        double randomizer = random.random();
        if (randomizer < 0.33) {
            if (!highSkill.isEmpty()) result = highSkillIndividual();
            else if (!mediumSkill.isEmpty()) result = mediumSkillIndividual();
            else result = lowSkillIndividual();
        }
        else if (randomizer < 0.66) {
            if (!mediumSkill.isEmpty()) result = mediumSkillIndividual();
            else if (!lowSkill.isEmpty()) result = lowSkillIndividual();
            else result = highSkillIndividual();
        }
        else {
            if (!lowSkill.isEmpty()) result = lowSkillIndividual();
            else if (!mediumSkill.isEmpty()) result = mediumSkillIndividual();
            else result = highSkillIndividual();
        }
        return result;
    }

    // Make random evenly-divided teams from arrays (without re-using names)
    public ArrayList<ArrayList<Individual>> generateTeams() {
        int division = size / 3;
        ArrayList<ArrayList<Individual>> result = new ArrayList<ArrayList<Individual>>();

        for (int i = 0; i < individuals.size() / size; i++) {

            // Populate individual teams
            ArrayList<Individual> currentTeam = new ArrayList<Individual>();
            for (int j = 0; j < division; j++) {
                if (!highSkill.isEmpty()) currentTeam.add(highSkillIndividual());
                else currentTeam.add(randomIndividual());
            }
            for (int j = 0; j < division; j++) {
                if (!mediumSkill.isEmpty()) currentTeam.add(mediumSkillIndividual());
                else currentTeam.add(randomIndividual());
            }
            for (int j = 0; j < division; j++) {
                if (!lowSkill.isEmpty()) currentTeam.add(lowSkillIndividual());
                else currentTeam.add(randomIndividual());
            }

            int remainder = size % 3;
            // Account for non-divisible cases
            while (remainder != 0 && (!highSkill.isEmpty() || !mediumSkill.isEmpty()
                    || !lowSkill.isEmpty())) {
                currentTeam.add(randomIndividual());
                remainder -= 1;
            }
            result.add(currentTeam);
        }

        return result;
    }

    // tests methods
    public static void main(String[] args) {

        // Test TeamMatcher constructor, classify, and generate team methods
        TeamMatcher matcher = new TeamMatcher("training-1.txt", "testing-1.txt",
                                              2); // Expected value:
        // all values are within 0.4 of each other
        matcher.classify();
        ArrayList<ArrayList<Individual>> teams = matcher.generateTeams();

        for (int i = 0; i < teams.size(); i++) {
            double teamBalance = 0;
            double teamHardSkills = 0;
            double teamSoftSkills = 0;
            for (int j = 0; j < teams.get(i).size(); j++) {
                teamBalance += teams.get(i).get(j).teamContribution();
                teamHardSkills += teams.get(i).get(j).hardSkills();
                teamSoftSkills += teams.get(i).get(j).softSkills();
            }
            StdOut.println("Expected team balance: < 0.4, Expected hard / soft skills: > 0.02");
            StdOut.println("Result: ");
            StdOut.println("Team " + (i + 1) + " balance: " + String.format("%.4f", teamBalance));
            StdOut.println(
                    "Team " + (i + 1) + " hard skills: " + String.format("%.4f", teamHardSkills));
            StdOut.println(
                    "Team " + (i + 1) + " soft skills: " + String.format("%.4f", teamSoftSkills));
            if (Math.abs(teamBalance) < 0.4 && teamHardSkills > 0.02 && teamSoftSkills > 0.02)
                StdOut.println("passed");
            StdOut.println();
        }
        StdOut.println();


        TeamMatcher matcher2 = new TeamMatcher("training-2.txt", "testing-3.txt", 6);
        matcher2.classify();
        ArrayList<ArrayList<Individual>> teams2 = matcher2.generateTeams();
        for (int i = 0; i < teams2.size(); i++) {
            double teamBalance2 = 0;
            double teamHardSkills2 = 0;
            double teamSoftSkills2 = 0;
            for (int j = 0; j < teams2.get(i).size(); j++) {
                teamBalance2 += teams2.get(i).get(j).teamContribution();
                teamHardSkills2 += teams2.get(i).get(j).hardSkills();
                teamSoftSkills2 += teams2.get(i).get(j).softSkills();
            }
            StdOut.println("Expected team balance: < 0.4, Expected hard / soft skills: > 0.1");
            StdOut.println("Result: ");
            StdOut.println("Team " + (i + 1) + " balance: " + String.format("%.4f", teamBalance2));
            StdOut.println(
                    "Team " + (i + 1) + " hard skills: " + String.format("%.4f", teamHardSkills2));
            StdOut.println(
                    "Team " + (i + 1) + " soft skills: " + String.format("%.4f", teamSoftSkills2));
            if (Math.abs(teamBalance2) < 0.4 && teamHardSkills2 > 0.1 && teamSoftSkills2 > 0.1)
                StdOut.println("passed");
            StdOut.println();
        }

        // Test getUnsorted method
        StdOut.println("Expected value: match testing-3.txt order");
        StdOut.println("Result: ");
        ArrayList<Individual> unsorted = matcher2.getUnsorted();
        boolean isUnsorted = false;
        for (int i = 0; i < unsorted.size(); i++) {
            StdOut.println(unsorted.get(i).name()); // Expected value: match testing-3.txt order
            if (unsorted.get(i).name().equals("ALEXANDER LIOU")) isUnsorted = true;
        }
        if (isUnsorted) StdOut.println("passed");

    }

}
