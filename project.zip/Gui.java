/*
    GUI for the program. Top has a place to input parameters (file names and
    team size). Middle shows overall roster and teams. Serves as a test because
    it should display every member. Bottom displays the stats of selected member
 */

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Objects;

public class Gui implements ActionListener {
    private JTextField input; // input text field
    private JButton button; // submit button
    private JTextArea roster; // roster text box
    private JTextArea team; // team text box
    private JTextArea stats; // stat display box
    private JComboBox<String> comboBox; // comboBox (dropdown menu) for individual stats
    private int counter; // counter for submit box to track inputs
    private String[] inputFiles; // array of input files
    private ArrayList<ArrayList<Individual>> sorted; // sorted teams


    // creates the main frame and lays out components
    public Gui() {
        ImageIcon logo = new ImageIcon("pton.png");
        inputFiles = new String[3];
        sorted = new ArrayList<ArrayList<Individual>>();
        counter = 0;

        // main frame: sets size and title
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(420, 520);
        frame.setTitle("TeamBuilder 9000");
        frame.setIconImage(logo.getImage());
        frame.setLayout(new FlowLayout());
        frame.setResizable(false);

        // contains text field and submit overall top panel
        JPanel inputPanel = new JPanel();
        inputPanel.setSize(420, 50);
        inputPanel.setBackground(Color.orange);

        // left roster text area
        roster = new JTextArea(15, 15);
        JScrollPane scroll0 = new JScrollPane(roster);
        roster.setEditable(false);

        // right team text area
        team = new JTextArea(15, 15);
        JScrollPane scroll1 = new JScrollPane(team);
        team.setEditable(false);

        // displays stats
        stats = new JTextArea(7, 30);
        JScrollPane scroll2 = new JScrollPane(stats);
        stats.setEditable(false);

        // bottom panels holding comboBox bottom panel
        JPanel statsPanel = new JPanel(new FlowLayout());
        statsPanel.setSize(420, 50);
        statsPanel.setBounds(0, 320, 420, 70);
        statsPanel.setBackground(Color.orange);

        // input text field
        input = new JTextField();
        input.setPreferredSize(new Dimension(250, 40));

        // submit button
        button = new JButton("Submit");
        button.addActionListener(this);
        button.setPreferredSize(new Dimension(100, 20));

        // members comboBox
        comboBox = new JComboBox<String>();
        comboBox.addActionListener(this);
        comboBox.setPrototypeDisplayValue("Member Stats                                         ");
        comboBox.setFocusable(false);

        // adding the various components to respective containers
        inputPanel.add(input);
        inputPanel.add(button);

        statsPanel.add(comboBox);

        frame.add(inputPanel);
        frame.add(scroll0);
        frame.add(scroll1);
        frame.add(statsPanel);
        frame.add(scroll2);

        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        // entering input files and doing the team making
        if (e.getSource() == button) {

            // allows for three inputs
            if (counter < 3) {

                // inputs file name to array, clears it for next entry
                String currentFile = input.getText();
                inputFiles[counter] = currentFile;
                input.setText("");
                counter++;

                // third input inserted, disable button, and calls the functions
                if (counter == 3) {
                    button.setEnabled(false);
                    counter = 1;

                    TeamMatcher team0 = new TeamMatcher(inputFiles[0], inputFiles[1],
                                                        Integer.parseInt(inputFiles[2]));
                    team0.classify();
                    sorted = team0.generateTeams();

                    // tests input files
                    StdOut.println("expected: training.txt, testing.txt, 7");
                    StdOut.println("Actual: ");
                    for (int i = 0; i < inputFiles.length; i++) {
                        StdOut.println(inputFiles[i]);
                    }


                    // populates the teams arraylist, and roster/team text area
                    for (int i = 0; i < sorted.size(); i++) {
                        team.append("Team " + (i + 1) + "\n");
                        for (int j = 0; j < sorted.get(i).size(); j++) {
                            String currentMember = sorted.get(i).get(j).name();

                            comboBox.addItem((i + 1) + " " + (j + 1)); // adds member to comboBox
                            roster.append(
                                    counter + ". Name: " + team0.getUnsorted().get(i + j).name()
                                            + "\n");
                            team.append((j + 1) + ". Name: " + currentMember + "\n");

                            counter++;
                        }
                        team.append("\n");
                    }
                }
            }
        }

        // fills comboBox
        if (e.getSource() == comboBox) {
            stats.setText("");
            int teamNum = (Integer.parseInt(
                    Objects.requireNonNull(comboBox.getSelectedItem()).toString().substring(0, 1)))
                    - 1;
            int member = (Integer.parseInt(comboBox.getSelectedItem().toString().substring(2)) - 1);

            stats.append(sorted.get(teamNum).get(member).toString());
        }
    }

    public static void main(String[] args) {
        new Gui();

        /*
            Feature: allows for three inputs before submit button is grayed out
            Test: We input three file names
            Expected: button is grayed out
            Result: Passed (Manually tested)

            Feature: text field cleared after every entry
            Test: observe if it does clear
            Expected: Clears after every click of submit
            Result: Passed (Manually tested)

            Feature: Displays roster of all members in right text area
            Test: Count how many entries there are
            Expected: Equivalent # entries to test file
            Result: Passed (Manually tested)

            Feature: comboBox with each team member
            Test: match up titles of entries to team number and member number
                  and match displayed data to our hand-calculated list
            Expected: titles to match, displayed stats to match
            Result: Passed (Manually tested)


         */
    }
}
