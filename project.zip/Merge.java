/*
    Merge sort to help sort individuals after having their distances calculated
    using the KNN algorithm
 */

public class Merge {

    // Sort an array of individuals
    public static void sort(Individual[] individuals) {
        Individual[] sortedIndividuals = new Individual[individuals.length];
        sort(individuals, sortedIndividuals, 0, individuals.length);

    }

    // Sort an array of individuals recursively into auxiliary array
    private static void sort(Individual[] a, Individual[] aux, int lo, int hi) {
        // Sort a[lo, hi).
        if (hi - lo <= 1) return;
        int mid = lo + (hi - lo) / 2;
        sort(a, aux, lo, mid);
        sort(a, aux, mid, hi);
        int i = lo, j = mid;
        for (int k = lo; k < hi; k++) {
            if (i == mid) aux[k] = a[j++];
            else if (j == hi) aux[k] = a[i++];
            else if (a[j].compareTo(a[i]) < 0) {
                aux[k] = a[j++];
            }
            else aux[k] = a[i++];
        }
        for (int k = lo; k < hi; k++) {
            a[k] = aux[k];
        }
    }

    // Tests mergesort methods
    public static void main(String[] args) {

        // Test sort method
        Individual max = new Individual("max-test.txt", "soft-keywords.txt", "hard-keywords.txt");
        Individual tharun = new Individual("tharun-test.txt", "soft-keywords.txt",
                                           "hard-keywords.txt");
        Individual yana = new Individual("yana-test.txt", "soft-keywords.txt", "hard-keywords.txt");
        Individual daniel = new Individual("daniel-test.txt", "soft-keywords.txt",
                                           "hard-keywords.txt");
        Individual skywalker = new Individual("skywalker-test.txt", "soft-keywords.txt",
                                              "hard-keywords.txt");


        Individual[] individuals = { max, tharun, yana, daniel };

        StdOut.println("Unsorted list: ");
        for (int i = 0; i < individuals.length; i++) {
            individuals[i].setDistance(skywalker);
            StdOut.println(individuals[i].name() + ": " + individuals[i].distance());
        }
        StdOut.println();

        sort(individuals);

        StdOut.println("Sorted list: ");
        for (int i = 0; i < individuals.length; i++) {
            StdOut.println(individuals[i].name() + ": " + individuals[i].distance());
        }
        StdOut.println();

        boolean isSorted = true;
        for (int i = 0; i < individuals.length - 1; i++) {
            if (individuals[i].compareTo(individuals[i + 1]) == 1) isSorted = false;
        }
        if (isSorted) StdOut.println("passed");


    }
}
