/*
       ADT for members that consists of a soft and hard skill rating that
       is calculated based on how many times keywords appear in their resume
       and dividing by the total number of words in their resume.
 */

import java.util.ArrayList;

public class Individual implements Comparable<Individual> {

    private String name; // name of individual
    private double hardSkills; // measures technical ability
    private double softSkills; // measures business ability
    private double label; // ranks individual in one of three skill classes
    private ST<String, Integer> softSkillsCounter;
    // counts the occurrences of soft skill keywords in resume
    private ST<String, Integer> hardSkillsCounter;
    // counts the occurrences of hard skill keywords in resume
    private double distance;
    // stores Euclidean distance between Individual's and another Individual's skill scores

    private ArrayList<String> resumeWords; // stores list of words in resume
    private ArrayList<String> softSkillsKeywords; // stores list of keywords for business ability
    private ArrayList<String> hardSkillsKeywords; // stores list of keywords for technical ability


    // Creates an individual object
    public Individual(String resumeFile, String softSkillsFile, String hardSkillsFile) {

        // Initialize keyword frequency counter
        softSkillsCounter = new ST<String, Integer>();
        hardSkillsCounter = new ST<String, Integer>();

        // Initialize hard and soft skills
        hardSkills = 0;
        softSkills = 0;

        // Create input streams for files
        In resumeList = new In(resumeFile);
        In softSkillsList = new In(softSkillsFile);
        In hardSkillsList = new In(hardSkillsFile);

        // Attribute label to individual
        label = resumeList.readDouble();

        // Flush remaining line and assign name to individual
        name = resumeList.readLine();
        name = resumeList.readLine();

        // Create arraylist to store keywords
        resumeWords = new ArrayList<String>();
        softSkillsKeywords = new ArrayList<String>();
        hardSkillsKeywords = new ArrayList<String>();


        // Add keywords to the arraylists
        while (!softSkillsList.isEmpty()) {
            softSkillsKeywords.add(softSkillsList.readString().toLowerCase());
        }

        while (!hardSkillsList.isEmpty()) {
            hardSkillsKeywords.add(hardSkillsList.readString().toLowerCase());
        }

        while (!resumeList.isEmpty()) {
            resumeWords.add(resumeList.readString().toLowerCase());
        }

        // Initialize all symbol tables with words in resume
        for (int i = 0; i < resumeWords.size(); i++) {
            String currentWord = resumeWords.get(i);

            if (!softSkillsCounter.contains(currentWord)) {
                softSkillsCounter.put(currentWord, 1);
            }
            else softSkillsCounter.put(currentWord, softSkillsCounter.get(currentWord) + 1);

            if (!hardSkillsCounter.contains(currentWord)) {
                hardSkillsCounter.put(currentWord, 1);
            }
            else hardSkillsCounter.put(currentWord, hardSkillsCounter.get(currentWord) + 1);

        }

        // Count the soft skills and hard skills word frequencies
        for (int i = 0; i < softSkillsKeywords.size(); i++) {
            String currentWord = softSkillsKeywords.get(i).toLowerCase();

            if (softSkillsCounter.contains(currentWord)) {
                softSkills += softSkillsCounter.get(currentWord);
            }
        }

        for (int i = 0; i < hardSkillsKeywords.size(); i++) {

            String currentWord = hardSkillsKeywords.get(i).toLowerCase();

            if (hardSkillsCounter.contains(currentWord)) {
                hardSkills += hardSkillsCounter.get(currentWord);
            }

        }

        softSkills /= softSkillsCounter.size();
        hardSkills /= hardSkillsCounter.size();
    }

    // Return hard skills score
    public double hardSkills() {
        return hardSkills;
    }

    // Return soft skills score
    public double softSkills() {
        return softSkills;
    }

    // Return team contribution score
    public double teamContribution() {
        return softSkills - hardSkills;
    }

    // Return individual label
    public double label() {
        return label;
    }

    // Modify individual label
    public void setLabel(double label) {
        this.label = label;
    }

    // Return individual name
    public String name() {
        return name;
    }

    // Return statistics of individual
    public String toString() {
        return "Name: " + name + "\nHard Skills: " + String.format("%.4f", hardSkills) +
                "\nSoft Skills: " + String.format("%.4f", softSkills) + "\nTeam Contribution: " +
                String.format("%.6f", teamContribution()) + "\nLabel: " + label;
    }

    // Return Euclidean distance of individual to another individual
    public double distance() {
        return distance;
    }

    // Set Euclidean distance of individual to another individual
    public void setDistance(Individual other) {
        double x0 = softSkills();
        double x1 = other.softSkills();
        double y0 = hardSkills();
        double y1 = other.hardSkills();
        distance = Math.sqrt(Math.pow(x1 - x0, 2) + Math.pow(y1 - y0, 2));
    }

    // Compare individuals by their Euclidean distances to another individual
    @Override
    public int compareTo(Individual other) {
        double difference = distance - other.distance;
        int result = 0;
        if (difference > 0) result = 1;
        else if (difference < 0) result = -1;
        return result;
    }


    // Test methods in Individual class
    public static void main(String[] args) {

        // Test constructor method with toString method
        Individual max = new Individual("max-test.txt", "soft-keywords.txt", "hard-keywords.txt");
        String expectedMax = "name: Max Machado, hardSkills: 0.0531, softSkills: 0.0204," +
                " teamContribution: -0.032653, label: 0.0";
        StdOut.println(
                "Expected value: " + max);// Expected value: name: Max Machado, hardSkills: 0.0531,
        // softSkills: 0.0204, teamContribution: -0.032653, label: 0.0
        StdOut.println("Result: " + max);
        if (expectedMax.equals(max.toString())) StdOut.println("passed");
        StdOut.println();

        // Test hard skills method
        StdOut.println("Hard Skills expected value: 0.0531");
        StdOut.println(
                "Result: " + String.format("%.4f", max.hardSkills())); // Expected value: 0.0531
        if (String.format("%.4f", max.hardSkills()).equals("0.0531")) StdOut.println("passed");
        StdOut.println();

        // Test soft skills method
        StdOut.println("Soft skills value: 0.0204");
        StdOut.println(
                "Result: " + String.format("%.4f", max.softSkills())); // Expected value: 0.0204
        if (String.format("%.4f", max.softSkills()).equals("0.0204")) StdOut.println("passed");
        StdOut.println();

        // Test team contribution method
        StdOut.println("Team contribution expected value: -0.0327");
        StdOut.println("Result: " + String.format("%.4f",
                                                  max.teamContribution())); // Expected value: -0.0367
        if (String.format("%.4f", max.teamContribution()).equals("-0.0327"))
            StdOut.println("passed");
        StdOut.println();

        // Test label method
        StdOut.println("Label expected value: 0.0");
        StdOut.println("Result: " + max.label()); // Expected value: 0.0
        if (max.label() == 0.0) StdOut.println("passed");
        StdOut.println();

        // Test name method
        StdOut.println("Name expected value: Max Machado");
        StdOut.println("Result: " + max.name()); // Expected value: Max Machado
        if (max.name().equals("Max Machado")) StdOut.println("passed");
        StdOut.println();

        // Test distance method
        Individual tharun = new Individual("tharun-test.txt", "soft-keywords.txt",
                                           "hard-keywords.txt");
        Individual yana = new Individual("yana-test.txt", "soft-keywords.txt", "hard-keywords.txt");
        max.setDistance(yana);

        StdOut.println("Distance expected value: 0.0217");
        StdOut.println("Result: " + String.format("%.4f", max.distance()));
        StdOut.println(String.format("%.4f", max.distance())); // Expected value: 0.0217
        if (String.format("%.4f", max.distance()).equals("0.0217")) StdOut.println("passed");
        StdOut.println();

        tharun.setDistance(yana);

        StdOut.println("Distance expected value: 0.0484");
        StdOut.println("Result: " + String.format("%.4f", tharun.distance()));
        StdOut.println(String.format("%.4f", tharun.distance())); // Expected value: 0.0484
        if (String.format("%.4f", max.distance()).equals("0.0484")) StdOut.println("passed");
        StdOut.println();

        // Test if individuals are comparable
        StdOut.println("Comparison expected value: -1");
        StdOut.println("Result: " + max.compareTo(tharun));
        StdOut.println(max.compareTo(tharun)); // Expected value: -1
        if (max.compareTo(tharun) == -1) StdOut.println("passed");
        StdOut.println();

    }

}
